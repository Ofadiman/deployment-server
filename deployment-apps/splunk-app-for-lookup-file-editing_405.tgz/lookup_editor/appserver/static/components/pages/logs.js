/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 1420:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {



var __createBinding = this && this.__createBinding || (Object.create ? function (o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  var desc = Object.getOwnPropertyDescriptor(m, k);
  if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
    desc = {
      enumerable: true,
      get: function get() {
        return m[k];
      }
    };
  }
  Object.defineProperty(o, k2, desc);
} : function (o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (o, v) {
  Object.defineProperty(o, "default", {
    enumerable: true,
    value: v
  });
} : function (o, v) {
  o["default"] = v;
});
var __importStar = this && this.__importStar || function (mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
  __setModuleDefault(result, mod);
  return result;
};
var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
var jsx_runtime_1 = __webpack_require__(74848);
var react_1 = __webpack_require__(96540);
// import { SWACollector } from "@splunk/dashboard-telemetry";
var withTokens_1 = __importDefault(__webpack_require__(5018));
var Dashboard_1 = __importDefault(__webpack_require__(55257));
var actions_1 = __importDefault(__webpack_require__(24093));
var TelemetryConstants_1 = __webpack_require__(1356);
var telemetryUtils_1 = __webpack_require__(53259);
var definition = __importStar(__webpack_require__(28190));
var Logs = (0, withTokens_1["default"])(Dashboard_1["default"]);
var DashboardLogs = function DashboardLogs() {
  (0, react_1.useEffect)(function () {
    // Send telemetry event
    var payload = {
      page: TelemetryConstants_1.META_LOGS
    };
    (0, telemetryUtils_1.sendTelemetryEvent)(TelemetryConstants_1.EVENT_PAGE_VIEWS, payload);
  }, []);
  return (0, jsx_runtime_1.jsx)(Logs, {
    definition: definition,
    actionMenus: actions_1["default"]
  });
};
exports["default"] = DashboardLogs;

/***/ }),

/***/ 26905:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {



var __importDefault = this && this.__importDefault || function (mod) {
  return mod && mod.__esModule ? mod : {
    "default": mod
  };
};
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
var i18n_1 = __webpack_require__(20259);
var pageLoader_1 = __importDefault(__webpack_require__(72647));
var Logs_1 = __importDefault(__webpack_require__(1420));
(0, pageLoader_1["default"])(Logs_1["default"], {
  pageTitle: (0, i18n_1._)('Logs'),
  showPageTitle: true,
  pageTitleBorder: true
});

/***/ }),

/***/ 28190:
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"visualizations":{"viz_chart_1":{"type":"splunk.area","dataSources":{"primary":"ds_search_1"},"title":"Logs by severity (over time)","options":{"yAxisAbbreviation":"off","y2AxisAbbreviation":"off","showRoundedY2AxisLabels":false,"legendTruncation":"ellipsisMiddle","showY2MajorGridLines":true,"stackMode":"stacked","legendLabels":["DEBUG","INFO","WARNING","ERROR","CRITICAL"],"seriesColors":["0xb2d16d","0x6ab7c8","0xfac61c","0xf8912c","0xd85d3d"]},"context":{},"eventHandlers":[]},"viz_table_1":{"type":"splunk.table","options":{"wrap":true,"rowNumbers":false,"dataOverlayMode":"none","drilldown":"cell","count":10},"dataSources":{"primary":"ds_search_2"},"title":"Logs by severity","eventHandlers":[{"type":"drilldown.customUrl","options":{"url":"$ds_root_endpoint:result.value$/app/search/search?q=index=_internal (sourcetype=lookup_editor_rest_handler OR sourcetype=lookup_backups_rest_handler) | rex field=_raw \\"(%3F<severity>(DEBUG)|(ERROR)|(WARNING)|(INFO)|(CRITICAL)) (%3F<message>.*)\\" | search severity=$row.severity.value|u$","newTab":true}}]},"viz_table_2":{"type":"splunk.table","options":{"wrap":true,"rowNumbers":false,"dataOverlayMode":"none","drilldown":"cell","count":10},"dataSources":{"primary":"ds_search_3"},"eventHandlers":[{"type":"drilldown.customUrl","options":{"url":"$ds_root_endpoint:result.value$/app/search/search?q=index=_internal (sourcetype=lookup_editor_rest_handler OR sourcetype=lookup_backups_rest_handler) $ds_tokens:result.severity_token$","newTab":true}}],"title":"Latest logs"}},"dataSources":{"ds_search_1":{"type":"ds.search","options":{"query":"index=_internal (sourcetype=lookup_editor_rest_handler OR sourcetype=lookup_backups_rest_handler) $ds_tokens:result.severity_token$ | rex field=_raw \\"(?<severity>(DEBUG)|(ERROR)|(WARNING)|(INFO)|(CRITICAL)) (?<message>.*)\\" | fillnull severity value=\\"UNDEFINED\\" | timechart count(severity) as count by severity","queryParameters":{"earliest":"$field1.earliest$","latest":"$field1.latest$"}},"name":"ds_search_1"},"ds_search_2":{"type":"ds.search","options":{"query":"index=_internal (sourcetype=lookup_editor_rest_handler OR sourcetype=lookup_backups_rest_handler) | rex field=_raw \\"(?<severity>(DEBUG)|(ERROR)|(WARNING)|(INFO)|(CRITICAL)) (?<message>.*)\\" | fillnull value=\\"undefined\\" vendor_severity | stats sparkline count by severity | sort -count","queryParameters":{"earliest":"$field1.earliest$","latest":"$field1.latest$"}},"name":"ds_search_2"},"ds_search_3":{"type":"ds.search","options":{"query":"index=_internal (sourcetype=lookup_editor_rest_handler OR sourcetype=lookup_backups_rest_handler) $ds_tokens:result.severity_token$\\n          | rex field=_raw \\"(?<severity>(DEBUG)|(ERROR)|(WARNING)|(INFO)|(CRITICAL)) (?<message>.*)\\"\\n          | sort -_time\\n          | eval time=_time\\n          | convert ctime(time)\\n          | table time severity message","queryParameters":{"earliest":"$field1.earliest$","latest":"$field1.latest$"}},"name":"ds_search_3"},"ds_tokens":{"type":"ds.search","options":{"queryParameters":{"earliest":"$field1.earliest$","latest":"$field1.latest$"},"query":"| makeresults count=1\\n| eval severity_input=\\"$severity$\\"\\n| eval list=split(severity_input,\\",\\")\\n| eval filterlist=mvfilter(!list IN (\\"*\\"))\\n| eval fields=\\"\\".mvjoin(mvmap(filterlist,\\"\\" . filterlist . \\"\\"), \\" OR \\").\\"\\"\\n| eval severity_token=case(severity_input==\\"\\",\\"\\", true(), fields)","enableSmartSources":true},"name":"ds_tokens"},"ds_root_endpoint":{"type":"ds.search","options":{"enableSmartSources":true,"query":"| rest /services/properties/web/settings/root_endpoint \\n|  fields value","queryParameters":{"earliest":"-24h@h","latest":"now"}},"name":"ds_root_endpoint"}},"defaults":{"dataSources":{"ds.search":{"options":{"queryParameters":{}}}}},"inputs":{"input_1":{"type":"input.timerange","title":"","options":{"token":"field1","defaultValue":"-24h@h,now"}},"input_2":{"options":{"items":[{"label":"All","value":"DEBUG OR INFO OR WARNING OR ERROR OR CRITICAL"},{"label":"Debug","value":"DEBUG"},{"label":"Informational","value":"INFO"},{"label":"Warning","value":"WARNING"},{"label":"Error","value":"ERROR"},{"label":"Critical","value":"CRITICAL"}],"defaultValue":["DEBUG OR INFO OR WARNING OR ERROR OR CRITICAL"],"token":"severity"},"title":"Severity","type":"input.multiselect"}},"layout":{"type":"grid","options":{"submitButton":true,"height":500},"structure":[{"item":"viz_chart_1","type":"block","position":{"x":0,"y":0,"w":600,"h":250}},{"item":"viz_table_2","type":"block","position":{"x":0,"y":250,"w":1200,"h":460}},{"item":"viz_table_1","type":"block","position":{"x":600,"y":0,"w":600,"h":250}}],"globalInputs":["input_1","input_2"]},"description":"","title":"Logs"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/amd define */
/******/ 	(() => {
/******/ 		__webpack_require__.amdD = function () {
/******/ 			throw new Error('define cannot be used indirect');
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/create fake namespace object */
/******/ 	(() => {
/******/ 		var getProto = Object.getPrototypeOf ? (obj) => (Object.getPrototypeOf(obj)) : (obj) => (obj.__proto__);
/******/ 		var leafPrototypes;
/******/ 		// create a fake namespace object
/******/ 		// mode & 1: value is a module id, require it
/******/ 		// mode & 2: merge all properties of value into the ns
/******/ 		// mode & 4: return value when already ns object
/******/ 		// mode & 16: return value when it's Promise-like
/******/ 		// mode & 8|1: behave like require
/******/ 		__webpack_require__.t = function(value, mode) {
/******/ 			if(mode & 1) value = this(value);
/******/ 			if(mode & 8) return value;
/******/ 			if(typeof value === 'object' && value) {
/******/ 				if((mode & 4) && value.__esModule) return value;
/******/ 				if((mode & 16) && typeof value.then === 'function') return value;
/******/ 			}
/******/ 			var ns = Object.create(null);
/******/ 			__webpack_require__.r(ns);
/******/ 			var def = {};
/******/ 			leafPrototypes = leafPrototypes || [null, getProto({}), getProto([]), getProto(getProto)];
/******/ 			for(var current = mode & 2 && value; typeof current == 'object' && !~leafPrototypes.indexOf(current); current = getProto(current)) {
/******/ 				Object.getOwnPropertyNames(current).forEach((key) => (def[key] = () => (value[key])));
/******/ 			}
/******/ 			def['default'] = () => (value);
/******/ 			__webpack_require__.d(ns, def);
/******/ 			return ns;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		// The chunk loading function for additional chunks
/******/ 		// Since all referenced chunks are already included
/******/ 		// in this file, this function is empty here.
/******/ 		__webpack_require__.e = () => (Promise.resolve());
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/runtimeId */
/******/ 	(() => {
/******/ 		__webpack_require__.j = 378;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript && document.currentScript.tagName.toUpperCase() === 'SCRIPT')
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl + "../../";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		__webpack_require__.b = document.baseURI || self.location.href;
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			378: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunklookup_editor_build"] = self["webpackChunklookup_editor_build"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [395], () => (__webpack_require__(26905)))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;